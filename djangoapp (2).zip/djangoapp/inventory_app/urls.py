from django.urls import path
from inventory_app import views


# urlpatterns = [
#     path('', views.index, name='index'),
#     path('homepage',views.homepage, name='homepage'),
#     path('product', views.product , name='product'),
#     path('customers', views.customers , name='customers'),
   
# ] 


from .views import OrderListView, OrderCreateView, OrderUpdateView, OrderDeleteView


from .views import BaseView

from .views import *


urlpatterns = [
    path('',views.homepage, name='homepage'),
    path('base', BaseView.as_view(), name='base'),
    path('product', views.product , name='product'),
    path('customers', views.customers , name='customers'),
    path('order_list', OrderListView.as_view(), name='order_list'),
    path('orders/new/', OrderCreateView.as_view(), name='order_create'),
    path('orders/<int:pk>/edit/', OrderUpdateView.as_view(), name='order_update'), 
    path('orders/<int:pk>/delete/', OrderDeleteView.as_view(), name='order_delete'),
    path('product_list', ProductListView.as_view(), name='product_list'),
    path('product/add/', ProductCreateView.as_view(), name='product_create'),
    path('product/<int:pk>/', ProductUpdateView.as_view(), name='product_update'),
    path('product/<int:pk>/delete/', ProductDeleteView.as_view(), name='product_delete'),
]









