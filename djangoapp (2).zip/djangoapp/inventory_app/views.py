from django.shortcuts import render
from .models import Product, Order
from django.http import HttpResponse
from django.template import loader

from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.shortcuts import render, redirect, get_object_or_404


from django.views.generic import TemplateView



class BaseView(TemplateView):
    template_name = 'pages/base.html'

class OrderListView(ListView): 
    model = Order
    template_name = 'pages/order_list.html'
    context_object_name = 'orders'

class OrderCreateView(CreateView):
    model = Order
    template_name = 'pages/order_form.html'
    fields = ['product', 'staff', 'order_quantity']
    success_url = reverse_lazy('order_list')

class OrderUpdateView(UpdateView):
    model = Order
    template_name = 'pages/order_form.html'
    fields = ['product', 'staff', 'order_quantity']
    success_url = reverse_lazy('order_list')

class OrderDeleteView(DeleteView):
    model = Order
    template_name = 'pages/order_confirm_delete.html'
    success_url = reverse_lazy('order_list')

def homepage(request):
    return render(request, 'pages/homepage.html')
def product(request):
    myproducts = Product.objects.all().values()
    template = loader.get_template('pages/product.html')
    context = {'myproducts': myproducts}  
    return HttpResponse(template.render(context,request))

def customers(request): 
    return render(request, 'pages/customers.html')
def members(request):
    template = loader.get_template('myfirst.html')
    return HttpResponse(template.render())

class ProductListView(ListView):
    model = Product
    template_name = 'pages/product_list.html'


class ProductCreateView(CreateView):
    model = Product
    template_name = 'pages/product_form.html'
    fields = '__all__'
    success_url = reverse_lazy('product_list')


class ProductUpdateView(UpdateView):
    model = Product
    template_name = 'pages/product_form.html'
    fields = '__all__'

class ProductDeleteView(DeleteView):
    model = Product
    template_name = 'pages/product_confirm.html'
    success_url = reverse_lazy('product_list')





