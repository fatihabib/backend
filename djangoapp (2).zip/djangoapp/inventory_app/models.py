from django.db import models
from django.contrib.auth.models import User

# Create your models here. 
category = (
    ('stationary', 'stationary'),
    ('Snickers', 'Snickers'),
    ('Crocs', 'Crocs'),
)


class Product(models.Model):
    name = models.CharField(max_length=100, null=True)
    category = models.CharField(max_length=20, choices=category, null=True)
    quantity = models.PositiveIntegerField(null=True)
    price = models.DecimalField(decimal_places=2, max_digits=10000, null=True)
    date = models.DateTimeField(auto_now=True)


    def __str__(self):
        return f'{self.name}-{self.quantity}'

# on_delete=models.CASCADE,
#  models.CASCADE
class Order(models.Model):
    product = models.ForeignKey(Product,on_delete=models.CASCADE, null=True)
    staff = models.ForeignKey(User,models.CASCADE, null=True)
    order_quantity = models.PositiveIntegerField(null=True)
    date = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f'{self.product} ordered by {self.staff.username}'
    
class Members(models.Model):
  firstname = models.CharField(max_length=255)
  lastname = models.CharField(max_length=255)


from django.db import models

class Patient(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField()
    birth_date = models.DateField(max_length=255)

    def __str__(self):
        return self.name